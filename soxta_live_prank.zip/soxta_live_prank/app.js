(() => {
const $ = id => document.getElementById(id);
const avatars = ["🧢","😎","🌸","⚽","🐼","🦊","🌙","🔥","🧿","🐯","💫","🦋","🎧","🐸","⭐","🌈"];
const namesUz = ["Azizbek","Malika","Jasur","Diyor","Shahnoza","Bekzod","Madina","Futbolchi_07","Sardor","Nodira","Umid","Lola","Temur","Zarina","Ali_uz","Shox"];
const namesRu = ["Алина","Максим","Дима","София","Артур","Маша","Тимур","Лиза","Даня","Кирилл","Ника","Артём"];
const phrases = {
  greet:["Va alaykum salom! 👋","Salom hammaga 😍","Assalomu alaykum 🔥","Salom salom! ❤️","Qalesizlar chat? 😄"],
  football:["Qaysi jamoaga muxlissiz? ⚽","Futbol zo‘r mavzu 🔥","Bugun kim yutadi deb o‘ylaysiz?","Realmi yoki Barsami? 👀","Futbol gap bo‘lishi mumkin emas 😂","Lokomotiv olg‘a! ⚽"],
  joke:["😂😂😂 gap yo‘q","Voy kuldirdiz-ku 🤣","Yana bitta hazil ayting 😭","Chat portladi 😂🔥","😂😂 zo‘r ekan"],
  question:["Zo‘r savol ekan 🤔","Menimcha ha 😄","Boshqalar nima deydi? 👀","Yaxshi savol! ❤️","Chat, fikringiz qanday?"],
  generic:["Zo‘r efir 🔥","Qayerdansizlar? 👀","Ovoz yaxshi eshitilyaptimi? 🎙️","Like bosib qo‘yinglar ❤️","Kim yangi kirdi? 👋","Gapiring, chat shu yerda 😄","Salom do‘stlar!","Nima yangiliklar? 😎","Efir kayfiyati zo‘r ✨","😂😂","Yurakchalar qani ❤️🔥","Kim oxirigacha ko‘radi? 👀"],
  russian:["Привет всем! 👋","Классный эфир 🔥","Откуда вы? 👀","Ахаха 😂😂","Что обсуждаем сегодня?","Ставим лайк ❤️","Очень интересно! 😎"]
};
let live = true, camStream = null, recognition = null, micOn = false, cameraOn = false;
let started = Date.now(), timer = null, chatTimer = null, viewerTimer = null, likeCount = 2400, lang = "uz", speed = "normal", activity = 2;
const rand = a => a[Math.floor(Math.random()*a.length)];
const currentViewers = () => Number($("viewerSlider").value);
const getPhrase = topic => {
  if (lang === "ru") return rand(phrases.russian);
  if (lang === "mix" && Math.random() < .3) return rand(phrases.russian);
  return rand(phrases[topic] || phrases.generic);
};
function showToast(text) {
  $("toast").textContent = text; $("toast").classList.add("show");
  clearTimeout(showToast.t); showToast.t = setTimeout(()=>$("toast").classList.remove("show"),2600);
}
function addMessage(name, avatar, text, host=false) {
  const node = document.createElement("div"); node.className = "chat-message" + (host ? " host":"");
  const av = document.createElement("div"); av.className="chat-avatar"; av.textContent=avatar;
  const body=document.createElement("div"); body.className="chat-body";
  const nm=document.createElement("div"); nm.className="chat-name"; nm.textContent=name + (host ? " · siz":"");
  const tx=document.createElement("div"); tx.className="chat-text"; tx.textContent=text;
  body.append(nm,tx); node.append(av,body); $("chat").append(node);
  while($("chat").children.length>7) $("chat").firstElementChild.remove();
}
function botMessage(topic="generic") {
  if(!live) return;
  const name = lang==="ru" ? rand(namesRu) : rand(namesUz);
  addMessage(name,rand(avatars),getPhrase(topic));
}
function setTopic(text) {
  const t=text.toLowerCase();
  if(/salom|assalomu|привет|здравствуй/.test(t)) return "greet";
  if(/futbol|football|gol|jamoa|real|barsa|lokomotiv|спорт/.test(t)) return "football";
  if(/hazil|kul|😂|🤣|шут/.test(t)) return "joke";
  if(/[?？]|nima|qanday|kim|nega|что|как|кто/.test(t)) return "question";
  return "generic";
}
function reactToSpeech(text) {
  const topic=setTopic(text);
  const count = activity===1 ? 1 : activity===2 ? 2 : 3+Math.floor(Math.random()*2);
  showToast("🤖 AI chat mavzuni tushundi");
  for(let i=0;i<count;i++) setTimeout(()=>botMessage(topic), 350+i*(speed==="fast"?450:speed==="slow"?1700:900));
}
function heart() {
  if(!$("heartsToggle").checked) return;
  const h=document.createElement("div");h.className="floating-heart";h.textContent=rand(["❤️","💖","💗","💜","🔥"]);
  h.style.right=(15+Math.random()*55)+"%";h.style.bottom=(90+Math.random()*30)+"px";
  $("heartLayer").append(h);setTimeout(()=>h.remove(),1900);
}
function updateViewers(n){$("viewerCount").textContent=n; $("viewerLabel").textContent=n;}
function startTimers(){
  clearInterval(timer); clearInterval(chatTimer); clearInterval(viewerTimer);
  timer=setInterval(()=>{if(!live)return;let s=Math.floor((Date.now()-started)/1000);$("duration").textContent=String(Math.floor(s/60)).padStart(2,"0")+":"+String(s%60).padStart(2,"0")},1000);
  chatTimer=setInterval(()=>{if(!live)return;botMessage(Math.random()<.4?"generic":rand(["generic","question","greet"]));if(activity>=2&&Math.random()<.5)setTimeout(()=>botMessage("generic"),700)}, (speed==="fast"?16000:speed==="slow"?42000:27000)/activity*2);
  viewerTimer=setInterval(()=>{if(!live)return;let n=currentViewers()+Math.round((Math.random()-.46)*(activity*4));n=Math.max(20,Math.min(500,n));$("viewerSlider").value=n;updateViewers(n);if(Math.random()<.18&&$("joinToggle").checked)showToast("👋 "+rand(namesUz)+" demo efirga qo‘shildi")},4200);
}
async function toggleCamera(){
  if(cameraOn){camStream?.getTracks().forEach(t=>t.stop());camStream=null;cameraOn=false;$("camera").style.display="none";$("demoScene").style.display="block";$("cameraState").textContent="O‘chiq";$("cameraToggle").querySelector("span").textContent="📷";showToast("Kamera o‘chirildi");return}
  try{
    camStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:"user"},audio:false});
    $("camera").srcObject=camStream;$("camera").style.display="block";$("demoScene").style.display="none";cameraOn=true;
    $("cameraState").textContent="Yoniq";$("cameraToggle").querySelector("span").textContent="📸";showToast("Kamera yoqildi");
  }catch(e){showToast("Kamera ochilmadi — demo ekran ishlayapti");}
}
function startSpeech(){
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR){$("speechStatus").textContent="Bu brauzerda mavjud emas";showToast("Nutqni tanish yo‘q — matn kiriting");return}
  try{
    recognition=new SR();recognition.lang=lang==="ru"?"ru-RU":"uz-UZ";recognition.continuous=true;recognition.interimResults=false;
    recognition.onresult=e=>{let r=e.results[e.results.length-1][0].transcript;if(r){addMessage("Siz","🎙️",r,true);reactToSpeech(r)}};
    recognition.onerror=()=>{$("speechStatus").textContent="Nutq aniqlanmadi";};
    recognition.onend=()=>{if(micOn){try{recognition.start()}catch(e){}}};
    recognition.start();$("speechStatus").textContent="Tinglayapti…";
  }catch(e){$("speechStatus").textContent="Ishga tushmadi";}
}
function stopSpeech(){if(recognition){micOn=false;try{recognition.onend=null;recognition.stop()}catch(e){}recognition=null}$("speechStatus").textContent="Mikrofonni yoqing"}
$("panelToggle").onclick=()=>$("controlPanel").classList.add("open");
$("closePanel").onclick=()=>$("controlPanel").classList.remove("open");
$("cameraToggle").onclick=toggleCamera;
$("micToggle").onclick=async()=>{
  if(micOn){stopSpeech();$("micState").textContent="O‘chiq";$("micToggle").querySelector("span").textContent="🎙️";showToast("Mikrofon tinglashi to‘xtadi");return}
  if(!navigator.mediaDevices?.getUserMedia){showToast("Mikrofon uchun HTTPS yoki localhost kerak");return}
  try{const s=await navigator.mediaDevices.getUserMedia({audio:true});s.getTracks().forEach(t=>t.stop());micOn=true;$("micState").textContent="Yoniq";$("micToggle").querySelector("span").textContent="🎤";startSpeech();}catch(e){showToast("Mikrofonga ruxsat berilmadi");}
};
$("liveToggle").onclick=()=>{
 live=!live;$("stage").classList.toggle("paused",!live);
 $("liveToggle").innerHTML=live?"<span>■</span> Efirni tugatish":"<span>▶</span> Demo LIVE boshlash";
 $("statusDot").classList.toggle("off",!live);$("statusText").textContent=live?"Demo efir faol":"Demo efir to‘xtatilgan";
 $("duration").textContent=live?"00:00":"PAUSE";if(live){started=Date.now();startTimers();showToast("🔴 Demo LIVE boshlandi")}else{clearInterval(chatTimer);clearInterval(viewerTimer);showToast("Demo efir to‘xtatildi")}
};
$("viewerSlider").oninput=e=>updateViewers(e.target.value);
$("activitySlider").oninput=e=>{activity=+e.target.value;$("activityLabel").textContent=["","Sokin","O‘rtacha","Juda faol"][activity];startTimers()};
$("likeBtn").onclick=()=>{likeCount+=Math.floor(1+Math.random()*7);$("likeCount").textContent=likeCount>=1000?(likeCount/1000).toFixed(1)+"K":likeCount;for(let i=0;i<3;i++)setTimeout(heart,i*90)};
$("giftBtn").onclick=()=>{if(!$("giftsToggle").checked){showToast("Sovg‘a effekti o‘chirilgan");return}const g=document.createElement("div");g.className="gift-burst";g.textContent=rand(["🎁","🌹","💎","🧸","🚀"]);$("stage").append(g);setTimeout(()=>g.remove(),1400);showToast("🎁 Virtual sovg‘a yuborildi")};
$("shareBtn").onclick=()=>showToast("Bu demo — ulashish amalga oshirilmaydi");
function sendManual(){
 const input=$("manualInput"), msg=input.value.trim();if(!msg)return;
 addMessage("Siz","🎙️",msg,true);reactToSpeech(msg);input.value="";
}
$("manualSend").onclick=sendManual;$("manualInput").addEventListener("keydown",e=>{if(e.key==="Enter")sendManual()});
function sendChat(){let msg=$("messageInput").value.trim();if(!msg)return;addMessage("Siz","👤",msg,true);$("messageInput").value="";reactToSpeech(msg)}
$("sendBtn").onclick=sendChat;$("messageInput").addEventListener("keydown",e=>{if(e.key==="Enter")sendChat()});
document.querySelectorAll("[data-lang]").forEach(b=>b.onclick=()=>{lang=b.dataset.lang;document.querySelectorAll("[data-lang]").forEach(x=>x.classList.toggle("active",x===b));if(micOn){stopSpeech();micOn=true;startSpeech()}showToast("Chat tili o‘zgartirildi")});
document.querySelectorAll("[data-speed]").forEach(b=>b.onclick=()=>{speed=b.dataset.speed;document.querySelectorAll("[data-speed]").forEach(x=>x.classList.toggle("active",x===b));$("speedLabel").textContent={slow:"Sekin",normal:"Normal",fast:"Tez"}[speed];startTimers()});
$("resetBtn").onclick=()=>{live=true;started=Date.now();$("viewerSlider").value=128;updateViewers(128);$("activitySlider").value=2;activity=2;$("activityLabel").textContent="O‘rtacha";lang="uz";speed="normal";document.querySelectorAll("[data-lang]").forEach(x=>x.classList.toggle("active",x.dataset.lang==="uz"));document.querySelectorAll("[data-speed]").forEach(x=>x.classList.toggle("active",x.dataset.speed==="normal"));$("heartsToggle").checked=true;$("joinToggle").checked=true;$("giftsToggle").checked=true;$("chat").innerHTML="";$("duration").textContent="00:00";$("liveToggle").innerHTML="<span>■</span> Efirni tugatish";$("statusDot").classList.remove("off");$("statusText").textContent="Demo efir faol";startTimers();botMessage("greet");showToast("Sozlamalar tiklandi")};
$("chat").addEventListener("click",()=>{});
updateViewers(128);botMessage("greet");setTimeout(()=>botMessage("generic"),700);setTimeout(()=>botMessage("question"),1450);startTimers();
})();