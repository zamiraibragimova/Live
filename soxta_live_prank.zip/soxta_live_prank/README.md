# LIVE Studio — Soxta LIVE Prank Demo

Bu loyiha telefon brauzerida ishlaydigan mahalliy ko‘ngilochar demo. U haqiqiy TikTok LIVE emas, hech qayerga efir uzatmaydi va virtual tomoshabinlar/izohlar sun’iy.

## Fayllar
- `index.html` — sahifa tuzilishi
- `style.css` — vertikal telefon dizayni
- `app.js` — kamera, nutqni tanish, chat, tomoshabinlar va effektlar

## Android telefonda ochish
1. ZIP faylni telefonga yuklab oling va arxivdan chiqaring.
2. `index.html` faylini brauzerda ochib ko‘ring. Faqat oddiy demo ekran va qo‘lda chat lokal faylda ishlashi mumkin.
3. Kamera/mikrofon va brauzer Speech Recognition uchun saytni HTTPS orqali joylashtirish yoki kompyuterda `localhost` server ishlatish kerak bo‘lishi mumkin. Androidda `file://` orqali ochilganda ruxsatlar ko‘pincha cheklanadi.
4. Sozlamalarni ochish uchun pastdagi ⚙ tugmasini bosing. Kamerani, mikrofonni, virtual tomoshabinlar sonini, chat faolligini va effektlarni boshqaring.

## Muhim
- Kamera oqimi faqat sahifada ko‘rsatiladi; audio/video yozib olinmaydi yoki yuborilmaydi.
- Nutqni tanish brauzer/cihazga bog‘liq. Ba’zi brauzerlar tanilgan nutqni tashqi nutq xizmatiga yuborishi mumkin; maxfiylik kerak bo‘lsa mikrofonni o‘chiq qoldiring.
- “AI chat” bu versiyada haqiqiy bulutli AI emas: so‘z kalitlariga qarab mahalliy demo javoblar tanlaydi. Haqiqiy AI uchun API kalitini frontendga joylashtirmasdan, server tomondagi endpoint kerak.
- Ekranda doim `PRANK DEMO` va `FAKAT MAHALLIY DEMO` yozuvlari ko‘rinadi.
